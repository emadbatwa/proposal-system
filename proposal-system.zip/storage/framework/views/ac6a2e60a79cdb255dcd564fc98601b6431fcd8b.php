<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2> عرض المقترح </h2>
                </div>

            </div>
            <br>
            <br>
        </div>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <br>

                    <h3 style="color: #1d643b"><?php echo e($proposal->title); ?></h3>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>محتوى المقترح</strong>
                    <br>
                    <div class="card">
                        <div class="card-body">
                            <div contenteditable="false">
                                <?php echo $proposal->content; ?>


                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>الموظف</strong>
                    <br>
                    <h4 style="color: blue">                    <?php echo e($proposal->user->name); ?></h4>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>حالة المقترح</strong>
                    <br>
                    <?php if($proposal->is_closed == 1): ?>
                        <button type="button" class="btn btn-outline-secondary">مغلق</button>
                        <?php if(Auth::user()->role_id == 2): ?>

                            <a class="btn btn-outline-success" href="<?php echo e(url('proposal/change-status/'. $proposal->id)); ?>"
                               role="button">
                                فتح المقترح
                            </a>
                        <?php endif; ?>

                    <?php else: ?>
                        <button type="button" class="btn btn-outline-success">مفتوح</button>
                        <?php if(Auth::user()->role_id == 2): ?>
                            <a class="btn btn-outline-secondary"
                               href="<?php echo e(url('proposal/change-status/'. $proposal->id)); ?>"
                               role="button">
                                إغلاق المقترح
                            </a>
                        <?php endif; ?>

                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <strong>تاريخ إنشاء المقترح</strong>
                    <br>
                    <?php echo e($proposal->created_at); ?>

                </div>
                <div class="form-group">
                    <strong>تاريخ آخر تعديل على المقترح</strong>
                    <br>
                    <?php echo e($proposal->updated_at); ?>

                </div>
                <div class="form-group">
                    <strong>المرفقات</strong>
                    <br>
                    <?php if(sizeof($attachments) != 0): ?>
                        <?php $__currentLoopData = $attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('attachment/'.$attachment->path)); ?>" target="_blank"
                               class="btn btn-outline-secondary">
                                <?php echo e($attachment->path); ?>

                            </a>                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        لا توجد مرفقات
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php if(Auth::user()->role_id == 2): ?>


            <div class="col-xs-12 col-sm-12 col-md-12">
                <a href="<?php echo e(url('proposal/'. $proposal->id .'/edit')); ?>" class="btn btn-primary">
                    تعديل المقترح
                </a>
            </div>
            <br>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <form action="<?php echo e(route('proposal.destroy',$proposal->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف المقترح</button>
                </form>
            </div>
            <br>
            <br>
            <br>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <a class="btn btn-dark" href="<?php echo e(route('proposal.index')); ?>" role="button">العودة للمقترحات</a>

            </div>





        <?php endif; ?>


    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proposal-system\resources\views/proposal/show.blade.php ENDPATH**/ ?>