<?php $__env->startSection('content'); ?>
    <div class="text-center">
        <?php if(Auth::user()->role_id == 2): ?>
            <h3>جميع المقترحات</h3>

        <?php else: ?>
            <h3>مقترحاتي</h3>

        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-8">
        </div>
        <?php if(Auth::user()->role_id == 1): ?>
            <div class="col-md-4 text-left">
                <div class="">
                    <a href="<?php echo e(url('proposal/create')); ?>" class="btn btn-success btn-lg">
                        <i class="fas fa-plus"></i>
                        إضافة مقترح جديد
                    </a>
                </div>
            </div>
        <?php endif; ?>

    </div>
    <hr>

    <?php if($proposals->count() > 0): ?>
        <table class="table table-bordered table-striped table-hover text-right">
            <thead>
            <tr>
                <th>#</th>
                <th>عنوان المقترح</th>
                <th>
                    المحتوى ...
                </th>
                <th>حالة المقترح</th>
                <?php if(Auth::user()->role_id == 2): ?>
                    <th>الموظف</th>
                <?php endif; ?>

                <th>العمليات</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $proposals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proposal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($proposal->id); ?></td>
                    <td><a href="<?php echo e(url('proposal', $proposal->id)); ?>"><?php echo e($proposal->title); ?></a></td>
                    <td>
                        <div contenteditable="false">
                            <?php echo mb_substr($proposal->content , 0 , 150); ?> ...

                        </div>
                    </td>
                    <?php if($proposal->is_closed == 1): ?>
                        <td>
                            <button type="button" class="btn btn-outline-secondary">مغلق</button>

                        </td>

                    <?php else: ?>
                        <td>
                            <button type="button" class="btn btn-outline-success">مفتوح</button>

                        </td>

                    <?php endif; ?>

                    <?php if(Auth::user()->role_id == 2): ?>
                        <td><?php echo e($proposal->user->name); ?></td>
                    <?php endif; ?>

                    <td>
                        <div class="row">
                            <div class="col-md-4">
                                <a href="<?php echo e(url('proposal', $proposal->id)); ?>" class="btn btn-primary">
                                    التفاصيل
                                </a>
                            </div>
                            <?php if(Auth::user()->role_id == 2): ?>
                                <div class="col-md-4">
                                    <a href="<?php echo e(url('proposal/'. $proposal->id .'/edit')); ?>" class="btn btn-primary">
                                        تعديل
                                    </a>
                                </div>
                                <div class="col-md-4">
                                    <form action="<?php echo e(route('proposal.destroy',$proposal->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">حذف</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php echo $proposals->links(); ?>


    <?php else: ?>
        <div class="text-center">
            <h3>لا توجد مقترحات حتى الآن </h3>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proposal-system\resources\views/proposal/index.blade.php ENDPATH**/ ?>