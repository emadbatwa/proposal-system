<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb text-center">
            <div class="pull-left">
                <h2>تعديل مقترح</h2>
            </div>
            <div class="pull-right text-left">
                <a class="btn btn-primary" href="<?php echo e(route('proposal.index')); ?>"> العودة للمقترحات</a>
            </div>
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger text-center">
            <strong>فشل التعديل! </strong>الرجاء التحقق من صحة البيانات المدخلة<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form class="text-center" action="<?php echo e(route('proposal.update',$proposal->id)); ?>" method="POST"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>عنوان المقترح:</strong>
                    <input type="text" name="title" value="<?php echo e($proposal->title); ?>" class="form-control"
                           placeholder="الرجاء كتابة عنوان مختصر وموجز">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>محتوى المقترح</strong>
                    <textarea class="ckeditor form-control" style="height:150px" name="content">
                        <?php echo $proposal->content; ?>

                    </textarea></div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">تعديل المقترح</button>
            </div>
        </div>

    </form>

    <script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            $('.ckeditor').ckeditor();
        });
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $(".btn-success").click(function () {
                var lsthmtl = $(".clone").html();
                $(".increment").after(lsthmtl);
            });
            $("body").on("click", ".btn-danger", function () {
                $(this).parents(".hdtuto control-group lst").remove();
            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\proposal-system\resources\views/proposal/edit.blade.php ENDPATH**/ ?>