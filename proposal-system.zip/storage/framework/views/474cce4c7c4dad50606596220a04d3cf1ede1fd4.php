<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">


    <!-- Styles -->
    <style>
        html, body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 100vh;
            margin: 0;
        }

        .full-height {
            height: 100vh;
        }

        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 84px;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 13px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }

        .m-b-md {
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
<div class="flex-center position-ref full-height">
    <?php if(Route::has('login')): ?>
        <div class="top-right links">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/proposal')); ?>">مقترحاتي</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">تسجيل الدخول</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">تسجيل جديد</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="content">
        
        
        
        <section class="jumbotron text-center">
            <div class="container">
                <h1 class="jumbotron-heading">بوابة إدارة المقترحات </h1>

                <?php if(auth()->guard()->guest()): ?>
                    <p>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-primary my-2">تسجيل جديد</a>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-secondary my-2">تسجيل الدخول</a>
                    </p>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <a href="proposal" class="btn btn-primary my-2">عرض المقترحات</a>
                    <br>
                <?php endif; ?>

                <img src="/image/logo.png" alt="شعار الرئاسة العامة لشؤون المسجد الحرام والمسجد النبوي"
                     width="500" height="600">
            </div>
        </section>


    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\proposal-system\resources\views/welcome.blade.php ENDPATH**/ ?>